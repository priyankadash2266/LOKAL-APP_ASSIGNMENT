import AsyncStorage from '@react-native-async-storage/async-storage';
import { createAsyncThunk, createSlice, PayloadAction } from '@reduxjs/toolkit';
import type { Job, JobsState } from '../types';

const BOOKMARKS_STORAGE_KEY = '@jobs_bookmarks';

export const fetchJobs = createAsyncThunk(
    'jobs/fetchJobs',
    async (page: number) => {
        const url = `https://testapi.getlokalapp.com/common/jobs?page=${page}`;
        const pageSize = 20;

        console.log('\n=== Fetching Jobs ===');
        console.log('Request Details:', {
            url,
            page,
            pageSize,
            timestamp: new Date().toISOString(),
            currentTimeLocal: new Date().toLocaleTimeString()
        });

        try {
            console.log('Making API request with headers:', {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            });
            const response = await fetch(url);

            console.log('Response Details:', {
                status: response.status,
                statusText: response.statusText,
                headers: Object.fromEntries([
                    ['content-type', response.headers.get('content-type')],
                    ['content-length', response.headers.get('content-length')],
                    ['cache-control', response.headers.get('cache-control')],
                ].filter(([_, v]) => v !== null) as [string, string][]),
                ok: response.ok
            });

            if (!response.ok) {
                const errorText = await response.text();
                console.error('API Error Response:', errorText);
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            let data;
            const responseText = await response.text();
            // console.log('Raw Response Text:', responseText);

            try {
                data = JSON.parse(responseText);
                console.log('\nParsed API Response:', {
                    hasData: !!data,
                    dataType: typeof data,
                    keys: data ? Object.keys(data) : [],
                    resultsPresent: !!data?.results,
                    resultsType: data?.results ? typeof data.results : 'undefined',
                    resultsLength: data?.results?.length || 0
                });
            } catch (parseError) {
                console.error('JSON Parse Error:', {
                    error: parseError,
                    responseText: responseText.substring(0, 200) + '...' // First 200 chars
                });
                throw new Error('Failed to parse API response');
            }

            // Validate response data
            if (!data || !data.results) {
                console.error('\nInvalid Response Format:', {
                    hasData: !!data,
                    hasResults: data && !!data.results,
                    receivedData: data
                });
                return {
                    jobs: [],
                    hasMore: false,
                    total: 0
                };
            }

            // Process and validate results
            // Filter out non-job entries (like ads with type 1040)
            const results = Array.isArray(data.results)
                ? data.results.filter((item: { type: number }) => item.type !== 1040)
                : [];

            console.log('\nValidating Results:', {
                isArray: Array.isArray(results),
                actualLength: results.length,
                expectedPageSize: pageSize,
                sampleJob: results[0] ? {
                    id: results[0].id,
                    title: results[0].title,
                    hasRequiredFields: !!(results[0].id && results[0].title)
                } : 'No jobs in results'
            });

            // Note: This API always has more pages available
            // Each page returns 11 jobs consistently
            // No need to check for hasMore - we can always load the next page
            console.log('\n=== Pagination Analysis ===', {
                currentPage: page,
                resultsInThisPage: results.length,
                // Always has more pages
                hasMore: true
            });

            const responseData = {
                jobs: results,
                hasMore: true, // Always true since API always has more pages
                total: data.total || 0,
                currentPage: page
            };

            console.log('\nProcessed Response:', {
                jobsCount: results.length,
                hasMore: responseData.hasMore,
                total: responseData.total,
                firstJobId: results[0]?.id,
                lastJobId: results[results.length - 1]?.id,
                pageRequested: page,
                receivedExpectedAmount: results.length === pageSize,
                dataIntegrity: results.every((job: Job) => job.id && job.title),
                timestamp: new Date().toISOString()
            });

            return responseData;
        } catch (error: any) {
            console.error('\nAPI Error:', {
                name: error?.name || 'Unknown Error',
                message: error?.message || 'An unknown error occurred',
                stack: error?.stack || 'No stack trace available'
            });
            throw error;
        }
    }
);

export const loadBookmarkedJobs = createAsyncThunk(
    'jobs/loadBookmarkedJobs',
    async () => {
        const storedBookmarks = await AsyncStorage.getItem(BOOKMARKS_STORAGE_KEY);
        return storedBookmarks ? JSON.parse(storedBookmarks) : [];
    }
);

const initialState: JobsState = {
    jobs: [],
    bookmarkedJobs: [],
    currentPage: 1,
    hasMore: true,
    total: 0,
    loading: false,
    error: null,
};

const jobsSlice = createSlice({
    name: 'jobs',
    initialState,
    reducers: {
        toggleBookmark: (state, action: PayloadAction<number>) => {
            const jobId = action.payload;
            const index = state.bookmarkedJobs.indexOf(jobId);

            if (index === -1) {
                state.bookmarkedJobs.push(jobId);
            } else {
                state.bookmarkedJobs.splice(index, 1);
            }

            // Save to AsyncStorage
            AsyncStorage.setItem(
                BOOKMARKS_STORAGE_KEY,
                JSON.stringify(state.bookmarkedJobs)
            );
        },
        clearJobs: (state) => {
            state.jobs = [];
            state.currentPage = 1;
            state.hasMore = true;
            state.error = null;
        }
    },
    extraReducers: (builder) => {
        builder
            .addCase(fetchJobs.pending, (state) => {
                console.log('=== Redux: fetchJobs.pending ===', {
                    currentState: {
                        jobsCount: state.jobs.length,
                        currentPage: state.currentPage,
                        loading: state.loading,
                        error: state.error
                    }
                });
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchJobs.fulfilled, (state, action) => {
                console.log('\n=== Redux: fetchJobs.fulfilled ===');
                console.log('Before Update:', {
                    existingJobs: state.jobs.length,
                    currentPage: state.currentPage,
                    loading: state.loading,
                    hasMore: state.hasMore,
                    timestamp: new Date().toISOString()
                });

                state.loading = false;
                // Store the current page (don't increment yet)
                state.currentPage = action.meta.arg;
                console.log('\n=== Page Management ===', {
                    requestedPage: action.meta.arg,
                    currentPage: state.currentPage,
                    nextPage: state.currentPage + 1, // Next page will be current + 1
                    hasMore: action.payload.hasMore,
                    jobsReceived: action.payload.jobs.length,
                    timestamp: new Date().toISOString()
                });

                console.log('\n##################');
                console.log('### NEW PAGE DATA RECEIVED ###');
                console.log('##################\n');

                if (action.meta.arg === 1) {
                    console.log('🔄 First page: Replacing all jobs');
                    console.log('\n=== NEW JOBS ===');
                    console.log(action.payload.jobs.map((job: Job) =>
                        `${job.id}: ${job.title}`
                    ).join('\n'));
                    state.jobs = action.payload.jobs;
                } else {
                    console.log('📥 Additional page: Processing new data');

                    console.log('\n=== EXISTING JOBS ===');
                    console.log(state.jobs.map((job: Job) =>
                        `${job.id}: ${job.title}`
                    ).join('\n'));

                    console.log('\n=== NEW JOBS RECEIVED ===');
                    console.log(action.payload.jobs.map((job: Job) =>
                        `${job.id}: ${job.title}`
                    ).join('\n'));

                    const existingIds = new Set(state.jobs.map(job => job.id));
                    const newJobs = action.payload.jobs.filter(
                        (newJob: Job) => !existingIds.has(newJob.id)
                    );

                    console.log('\n=== UNIQUE NEW JOBS ===');
                    console.log(newJobs.map((job: Job) =>
                        `${job.id}: ${job.title}`
                    ).join('\n'));

                    console.log('\n=== SUMMARY ===');
                    console.log({
                        existingJobCount: state.jobs.length,
                        newJobsReceived: action.payload.jobs.length,
                        uniqueNewJobs: newJobs.length,
                        duplicatesFiltered: action.payload.jobs.length - newJobs.length,
                        totalAfterMerge: state.jobs.length + newJobs.length,
                        pageRequested: action.meta.arg
                    });

                    state.jobs = [...state.jobs, ...newJobs];
                }

                console.log('\n##################');
                console.log('### DATA PROCESSING COMPLETE ###');
                console.log('##################\n');

                // Update hasMore based on the response
                state.hasMore = action.payload.hasMore;
                state.total = action.payload.total;

                const pageSize = 20;
                console.log('After Update:', {
                    totalJobs: state.jobs.length,
                    currentPage: state.currentPage,
                    hasMore: state.hasMore,
                    total: state.total,
                    timestamp: new Date().toISOString(),
                    allJobIds: state.jobs.map(job => job.id).join(', '),
                    lastJobId: state.jobs[state.jobs.length - 1]?.id,
                    nextPageToFetch: state.currentPage + 1,
                    receivedCount: action.payload.jobs.length,
                    pageSize: pageSize
                });
            })
            .addCase(fetchJobs.rejected, (state, action) => {
                console.log('=== Redux: fetchJobs.rejected ===', {
                    error: action.error,
                    currentState: {
                        jobsCount: state.jobs.length,
                        currentPage: state.currentPage,
                        loading: state.loading
                    }
                });
                state.loading = false;
                state.error = action.error.message || 'Failed to fetch jobs';
            })
            .addCase(loadBookmarkedJobs.fulfilled, (state, action) => {
                state.bookmarkedJobs = action.payload;
            });
    },
});

export const { toggleBookmark, clearJobs } = jobsSlice.actions;
export default jobsSlice.reducer;
