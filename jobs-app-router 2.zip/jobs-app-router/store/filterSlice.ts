import { createSlice, PayloadAction } from '@reduxjs/toolkit';

export interface FilterState {
    searchQuery: string;
    jobCategory: string | null;
    salaryRange: {
        min: number;
        max: number;
    } | null;
    location: string | null;
}

type FilterKey = keyof FilterState;
type FilterValue<K extends FilterKey> = FilterState[K];

const initialState: FilterState = {
    searchQuery: '',
    jobCategory: null,
    salaryRange: null,
    location: null,
};

const filterSlice = createSlice({
    name: 'filter',
    initialState,
    reducers: {
        setSearchQuery: (state, action: PayloadAction<string>) => {
            state.searchQuery = action.payload;
        },
        applyFilters: (state, action: PayloadAction<Partial<FilterState>>) => {
            return { ...state, ...action.payload };
        },
        removeFilter: (state, action: PayloadAction<FilterKey>) => {
            const key = action.payload;
            if (key === 'searchQuery') {
                state[key] = '';
            } else {
                state[key] = null;
            }
        },
        clearFilters: () => initialState,
    },
});

export const { setSearchQuery, applyFilters, removeFilter, clearFilters } = filterSlice.actions;
export default filterSlice.reducer;
