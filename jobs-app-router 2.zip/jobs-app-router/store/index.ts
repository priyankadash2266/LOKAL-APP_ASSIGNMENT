import { configureStore } from '@reduxjs/toolkit';
import filterReducer from './filterSlice';
import jobsReducer from './jobsSlice';

export const store = configureStore({
    reducer: {
        jobs: jobsReducer,
        filter: filterReducer,
    },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;

export default store;
