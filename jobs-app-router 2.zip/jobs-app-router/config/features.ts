// Feature flags for development and debugging
export const features = {
    // When true, shows debug information panel in the Jobs screen
    DEVELOPER_MODE: false,

    // Add other feature flags here as needed
} as const;

// Helper to check if a feature is enabled
export const isFeatureEnabled = (featureName: keyof typeof features): boolean => {
    return features[featureName];
};
