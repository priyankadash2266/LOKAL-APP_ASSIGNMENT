import { useEffect, useRef } from 'react';

export function useDebounce(
    callback: () => void,
    delay: number,
    deps: any[]
) {
    const timerRef = useRef<NodeJS.Timeout>();

    useEffect(() => {
        clearTimeout(timerRef.current);
        timerRef.current = setTimeout(callback, delay);

        return () => clearTimeout(timerRef.current);
    }, deps);
}
