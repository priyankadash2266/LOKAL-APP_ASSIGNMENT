import { Stack } from 'expo-router';
import { PaperProvider } from 'react-native-paper';
import { Provider } from 'react-redux';
import store from '../store';

export default function RootLayout() {
  return (
    <Provider store={store}>
      <PaperProvider>
        <Stack>
          <Stack.Screen
            name="(tabs)"
            options={{ headerShown: false }}
          />
          <Stack.Screen
            name="job/[id]"
            options={{
              title: 'Job Details',
              presentation: 'card',
            }}
          />
        </Stack>
      </PaperProvider>
    </Provider>
  );
}
