import { useMemo } from 'react';
import { FlatList, StyleSheet } from 'react-native';
import JobCard from '../../components/JobCard';
import { BodyText } from '../../components/StyledText';
import { View } from '../../components/Themed';
import { useAppSelector } from '../../store/hooks';
import type { Job, JobsState } from '../../types';

export default function BookmarksScreen() {
    const { jobs, bookmarkedJobs } = useAppSelector((state) => state.jobs as JobsState);
    const bookmarkedJobItems = useMemo(() =>
        jobs.filter((job: Job) => bookmarkedJobs.includes(job.id)),
        [jobs, bookmarkedJobs]
    );

    if (bookmarkedJobItems.length === 0) {
        return (
            <View style={styles.emptyContainer}>
                <BodyText>No bookmarked jobs yet</BodyText>
            </View>
        );
    }

    return (
        <View style={styles.container}>
            <FlatList
                data={bookmarkedJobItems}
                renderItem={({ item }: { item: Job }) => (
                    <JobCard job={item} />
                )}
                keyExtractor={(item) => item.id.toString()}
                contentContainerStyle={styles.list}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    emptyContainer: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    list: {
        padding: 16,
    },
});
