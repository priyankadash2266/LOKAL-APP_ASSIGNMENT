import { useCallback, useEffect, useMemo, useState } from 'react';
import { FlatList, NativeScrollEvent, StyleSheet, Text } from 'react-native';
import { ActivityIndicator } from 'react-native-paper';
import ErrorView from '../../components/ErrorView';
import JobCard from '../../components/JobCard';
import SearchBar from '../../components/SearchBar';
import { BodyText } from '../../components/StyledText';
import { View } from '../../components/Themed';
import { isFeatureEnabled } from '../../config/features';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import { clearJobs, fetchJobs, loadBookmarkedJobs } from '../../store/jobsSlice';
import type { Job, JobsState } from '../../types';

export default function JobsScreen() {
  console.log('\n=== JobsScreen Render ===');

  const dispatch = useAppDispatch();
  const { jobs, loading, error, hasMore, currentPage, total } = useAppSelector((state) => state.jobs as JobsState);
  const searchQuery = useAppSelector(state => state.filter.searchQuery);

  console.log('Current State:', {
    jobsCount: jobs.length,
    loading,
    error: error || 'none',
    hasMore,
    currentPage,
    total,
    searchQuery: searchQuery || 'none'
  });

  const filteredJobs = useMemo(() => {
    console.log('\n=== Filtering Jobs ===');
    if (!searchQuery.trim()) {
      console.log('No search query, returning all jobs');
      return jobs;
    }
    const filtered = jobs.filter(job =>
      job.title.toLowerCase().includes(searchQuery.toLowerCase())
    );
    console.log('Search Results:', {
      query: searchQuery,
      totalJobs: jobs.length,
      matchingJobs: filtered.length,
      firstMatch: filtered[0]?.title || 'none'
    });
    return filtered;
  }, [jobs, searchQuery]);

  const onRefresh = useCallback(() => {
    console.log('\n=== Refreshing Jobs ===');
    dispatch(clearJobs());
    dispatch(fetchJobs(1));
  }, [dispatch]);

  useEffect(() => {
    console.log('\n=== JobsScreen Mounted ===');
    const initializeData = async () => {
      try {
        console.log('Loading bookmarked jobs...');
        await dispatch(loadBookmarkedJobs()).unwrap();
        console.log('Bookmarks loaded successfully');

        console.log('Initiating initial jobs fetch...');
        dispatch(fetchJobs(1));
      } catch (error) {
        console.error('Initialization error:', error);
      }
    };
    initializeData();

    return () => {
      console.log('\n=== JobsScreen Unmounted ===');
    };
  }, [dispatch]);

  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [isNearThreshold, setIsNearThreshold] = useState(false);

  const loadMore = useCallback(() => {
    console.log('\n=== Load More Triggered ===');
    const debugInfo = {
      loading,
      isLoadingMore,
      hasMore,
      currentPage,
      jobsCount: jobs.length,
      scrollPosition,
      timestamp: new Date().toISOString()
    };
    console.log('Current State:', debugInfo);

    // Note: This API always has more pages available
    // Each page returns 11 jobs consistently
    // We only need to check loading states
    if (loading || isLoadingMore) {
      console.log('❌ Load more aborted:', {
        loading,
        isLoadingMore,
        currentPage,
        timestamp: new Date().toISOString()
      });
      return;
    }

    const nextPage = currentPage + 1;
    console.log('✨ Loading page', nextPage);

    setIsLoadingMore(true);
    dispatch(fetchJobs(nextPage))
      .finally(() => setIsLoadingMore(false));
  }, [dispatch, loading, isLoadingMore, hasMore, currentPage, jobs.length, scrollPosition]);

  const onScroll = useCallback((nativeEvent: NativeScrollEvent) => {
    const { layoutMeasurement, contentOffset, contentSize } = nativeEvent;

    // Calculate scroll position relative to content
    const scrollPosition = contentOffset.y;
    const visibleHeight = layoutMeasurement.height;
    const contentHeight = contentSize.height;

    // Calculate how far we've scrolled through the content
    const scrolledDistance = scrollPosition + visibleHeight;
    const scrollPercentage = (scrolledDistance / contentHeight) * 100;

    // Set threshold at 60%
    const threshold = 60;
    const isNearThreshold = scrollPercentage >= threshold;

    setScrollPosition(scrollPosition);
    setIsNearThreshold(isNearThreshold);

    console.log('\n=== Scroll Position Update ===');
    console.log({
      scrollPosition: Math.round(scrollPosition),
      visibleHeight: Math.round(visibleHeight),
      contentHeight: Math.round(contentHeight),
      scrolledDistance: Math.round(scrolledDistance),
      scrollPercentage: `${Math.round(scrollPercentage)}%`,
      threshold: `${threshold}%`,
      isNearThreshold,
      loading,
      isLoadingMore,
      hasMore,
      currentPage,
      jobsCount: jobs.length
    });

    // Check if we should load more
    // Note: API always has more pages, so we only check loading states
    const canLoadMore = !loading && !isLoadingMore;
    if (isNearThreshold && canLoadMore) {
      console.log('✨ Scroll threshold reached:', {
        scrollPercentage: `${Math.round(scrollPercentage)}%`,
        threshold: `${threshold}%`,
        currentPage,
        nextPage: currentPage + 1,
        jobsCount: jobs.length
      });
      loadMore();
    } else if (isNearThreshold) {
      console.log('⚠️ Scroll threshold reached but loading in progress:', {
        loading,
        isLoadingMore,
        currentPage
      });
    }
  }, [loading, isLoadingMore, hasMore, loadMore]);

  if (error) {
    console.log('\n=== Rendering Error View ===', {
      error,
      jobsLoaded: jobs.length
    });
    return (
      <ErrorView
        message={error}
        onRetry={() => {
          console.log('Retrying job fetch...');
          dispatch(fetchJobs(1));
        }}
      />
    );
  }

  console.log('\n=== Rendering Job List ===', {
    filteredJobsCount: filteredJobs.length,
    isLoading: loading,
    isFirstPage: currentPage === 1
  });

  return (
    <View style={styles.container}>
      {isFeatureEnabled('DEVELOPER_MODE') && (
        <View style={[styles.debugInfo, isNearThreshold && styles.debugInfoNearThreshold]}>
          <Text style={styles.debugText}>Page: {currentPage}</Text>
          <Text style={styles.debugText}>Total Jobs: {jobs.length}</Text>
          <Text style={styles.debugText}>Has More: {hasMore ? 'Yes' : 'No'}</Text>
          <Text style={styles.debugText}>Loading: {loading ? 'Yes' : 'No'}</Text>
          <Text style={styles.debugText}>Near Threshold: {isNearThreshold ? 'Yes' : 'No'}</Text>
        </View>
      )}
      <SearchBar />
      <FlatList
        data={filteredJobs}
        renderItem={({ item }: { item: Job }) => (
          <JobCard job={item} />
        )}
        keyExtractor={(item) => item.id.toString()}
        refreshing={loading && currentPage === 1}
        onRefresh={onRefresh}
        onScroll={(event) => onScroll(event.nativeEvent)}
        scrollEventThrottle={16}
        onEndReachedThreshold={0.4} // Backup trigger at 60%
        onEndReached={() => {
          console.log('⚡️ FlatList onEndReached backup trigger', {
            currentPage,
            hasMore,
            loading,
            isLoadingMore
          });
          // API always has more pages, only check loading states
          if (!loading && !isLoadingMore) {
            loadMore();
          }
        }}
        maxToRenderPerBatch={10}
        windowSize={5}
        removeClippedSubviews={true}
        maintainVisibleContentPosition={{
          minIndexForVisible: 0,
        }}
        contentContainerStyle={styles.list}
        ListEmptyComponent={
          loading && jobs.length === 0 ? (
            <View style={styles.centerContainer}>
              <ActivityIndicator animating size="large" />
              <BodyText style={styles.loadingText}>Loading jobs...</BodyText>
            </View>
          ) : (
            <View style={styles.centerContainer}>
              <BodyText>No jobs found</BodyText>
              {error && (
                <BodyText style={styles.errorText}>
                  {error}. Pull to refresh and try again.
                </BodyText>
              )}
            </View>
          )
        }
        ListFooterComponent={
          loading && jobs.length > 0 ? (
            <View style={styles.footer}>
              <ActivityIndicator animating size="small" />
            </View>
          ) : null
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  debugInfo: {
    padding: 8,
    backgroundColor: '#f0f0f0',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  debugInfoNearThreshold: {
    backgroundColor: '#ffe0e0',
  },
  debugText: {
    fontSize: 12,
    color: '#666',
    marginVertical: 2,
  },
  container: {
    flex: 1,
  },
  list: {
    padding: 16,
  },
  centerContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    minHeight: 200,
  },
  footer: {
    paddingVertical: 16,
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 8,
    color: '#666',
  },
  errorText: {
    marginTop: 8,
    color: '#dc3545',
    textAlign: 'center',
  },
});
