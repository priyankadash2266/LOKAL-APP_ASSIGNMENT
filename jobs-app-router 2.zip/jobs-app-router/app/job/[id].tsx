import { useLocalSearchParams } from 'expo-router';
import { ScrollView, StyleSheet } from 'react-native';
import { IconButton } from 'react-native-paper';
import { BodyText, HeadingText } from '../../components/StyledText';
import { View } from '../../components/Themed';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import { toggleBookmark } from '../../store/jobsSlice';
import type { Job, JobsState } from '../../types';

export default function JobScreen() {
    const { id } = useLocalSearchParams();
    const jobId = parseInt(id as string, 10);

    const dispatch = useAppDispatch();
    const { jobs, bookmarkedJobs } = useAppSelector((state) => state.jobs as JobsState);
    const job = jobs.find((j: Job) => j.id === jobId);
    const isBookmarked = bookmarkedJobs.includes(jobId);

    if (!job) {
        return (
            <View style={styles.container}>
                <BodyText>Job not found</BodyText>
            </View>
        );
    }

    return (
        <ScrollView contentContainerStyle={styles.container}>
            <View style={styles.header}>
                <HeadingText>{job.title}</HeadingText>
                <IconButton
                    icon={isBookmarked ? 'bookmark' : 'bookmark-outline'}
                    onPress={() => dispatch(toggleBookmark(jobId))}
                />
            </View>

            <View style={styles.section}>
                <HeadingText style={styles.sectionTitle}>Location</HeadingText>
                <BodyText>{job.primary_details.Place}</BodyText>
            </View>

            <View style={styles.section}>
                <HeadingText style={styles.sectionTitle}>Salary</HeadingText>
                <BodyText style={styles.salary}>
                    {job.salary_min && job.salary_max
                        ? `₹${job.salary_min.toLocaleString()} - ₹${job.salary_max.toLocaleString()}`
                        : job.primary_details.Salary || 'Not specified'}
                </BodyText>
            </View>

            <View style={[styles.section, styles.contactSection]}>
                <HeadingText style={styles.sectionTitle}>Contact</HeadingText>
                {job.whatsapp_no && (
                    <View style={styles.contactItem}>
                        <BodyText style={styles.contactLabel}>📱 WhatsApp:</BodyText>
                        <BodyText style={styles.contactValue}>{job.whatsapp_no}</BodyText>
                    </View>
                )}
                {job.custom_link && (
                    <View style={styles.contactItem}>
                        <BodyText style={styles.contactLabel}>📞 Phone:</BodyText>
                        <BodyText style={styles.contactValue}>
                            {job.custom_link.replace('tel:', '')}
                        </BodyText>
                    </View>
                )}
            </View>

            <View style={styles.section}>
                <HeadingText style={styles.sectionTitle}>Job Details</HeadingText>
                <BodyText>Category: {job.job_category}</BodyText>
                <BodyText>Role: {job.job_role}</BodyText>
                <BodyText>Type: {job.primary_details.Job_Type}</BodyText>
                <BodyText>Experience: {job.primary_details.Experience}</BodyText>
                <BodyText>Qualification: {job.primary_details.Qualification}</BodyText>
            </View>

            <View style={styles.section}>
                <HeadingText style={styles.sectionTitle}>Description</HeadingText>
                <BodyText>{job.other_details}</BodyText>
            </View>

            <View style={styles.section}>
                <HeadingText style={styles.sectionTitle}>Additional Info</HeadingText>
                <BodyText>Working Hours: {job.job_hours}</BodyText>
                <BodyText>Openings: {job.openings_count}</BodyText>
                {job.is_premium && (
                    <BodyText style={styles.premium}>Premium Job</BodyText>
                )}
            </View>

            <View style={styles.section}>
                <HeadingText style={styles.sectionTitle}>Company</HeadingText>
                <BodyText>{job.company_name}</BodyText>
            </View>

            <View style={styles.section}>
                <HeadingText style={styles.sectionTitle}>Dates</HeadingText>
                <BodyText>Posted: {new Date(job.created_on).toLocaleDateString()}</BodyText>
                <BodyText>Updated: {new Date(job.updated_on).toLocaleDateString()}</BodyText>
                <BodyText>Expires: {new Date(job.expire_on).toLocaleDateString()}</BodyText>
            </View>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        flexGrow: 1,
        padding: 16,
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 24,
    },
    section: {
        marginBottom: 24,
    },
    sectionTitle: {
        fontSize: 18,
        marginBottom: 8,
    },
    listItem: {
        marginBottom: 4,
    },
    premium: {
        color: '#FFD700',
        fontWeight: 'bold',
        marginTop: 4,
    },
    salary: {
        fontSize: 16,
        color: '#2E7D32',
        fontWeight: 'bold',
    },
    contactSection: {
        backgroundColor: '#f8f9fa',
        padding: 16,
        borderRadius: 8,
    },
    contactItem: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 8,
    },
    contactLabel: {
        width: 100,
        color: '#666',
    },
    contactValue: {
        flex: 1,
        color: '#333',
        fontWeight: '500',
    },
});
