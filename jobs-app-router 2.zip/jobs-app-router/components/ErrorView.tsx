import { StyleSheet } from 'react-native';
import { Button } from 'react-native-paper';
import { BodyText } from './StyledText';
import { View } from './Themed';

type Props = {
    message: string;
    onRetry: () => void;
};

export default function ErrorView({ message, onRetry }: Props) {
    return (
        <View style={styles.container}>
            <BodyText style={styles.message}>{message}</BodyText>
            <Button mode="contained" onPress={onRetry} style={styles.button}>
                Retry
            </Button>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        padding: 16,
    },
    message: {
        marginBottom: 16,
        textAlign: 'center',
    },
    button: {
        minWidth: 120,
    },
});
