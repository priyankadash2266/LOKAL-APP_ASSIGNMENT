import { router } from 'expo-router';
import { StyleSheet, TouchableOpacity } from 'react-native';
import { IconButton } from 'react-native-paper';
import { useAppDispatch, useAppSelector } from '../store/hooks';
import { toggleBookmark } from '../store/jobsSlice';
import type { Job, JobsState } from '../types';
import HighlightedText from './HighlightedText';
import { BodyText } from './StyledText';
import { View } from './Themed';

type Props = {
    job: Job;
};

export default function JobCard({ job }: Props) {
    console.log(`\n=== JobCard Render: ${job.id} ===`);

    const dispatch = useAppDispatch();
    const bookmarkedJobs = useAppSelector((state) => (state.jobs as JobsState).bookmarkedJobs);
    const searchQuery = useAppSelector(state => state.filter.searchQuery);
    const isBookmarked = bookmarkedJobs.includes(job.id);

    console.log('JobCard State:', {
        jobId: job.id,
        title: job.title,
        isBookmarked,
        hasSearchHighlight: !!searchQuery,
        openings: job.openings_count,
        applications: job.num_applications
    });

    return (
        <TouchableOpacity
            style={styles.container}
            onPress={() => {
                console.log('Navigating to job details:', {
                    jobId: job.id,
                    title: job.title,
                    company: job.company_name
                });
                router.push(`/job/${job.id}`);
            }}
        >
            <View style={styles.content}>
                <View style={styles.header}>
                    <View style={styles.titleContainer}>
                        <HighlightedText
                            text={job.title}
                            highlight={searchQuery}
                            style={styles.title}
                            numberOfLines={2}
                        />
                        <BodyText style={styles.companyName}>{job.company_name}</BodyText>
                        <View style={styles.statsRow}>
                            <BodyText style={styles.statsText}>
                                👥 {job.openings_count} openings
                            </BodyText>
                            {job.num_applications !== undefined && (
                                <BodyText style={styles.statsText}>
                                    📝 {job.num_applications} applications
                                </BodyText>
                            )}
                        </View>
                    </View>
                    <IconButton
                        icon={isBookmarked ? 'bookmark' : 'bookmark-outline'}
                        onPress={() => {
                            console.log('Toggling bookmark:', {
                                jobId: job.id,
                                currentState: isBookmarked,
                                newState: !isBookmarked,
                                totalBookmarks: bookmarkedJobs.length
                            });
                            dispatch(toggleBookmark(job.id));
                        }}
                    />
                </View>

                <View style={styles.details}>
                    <View style={styles.detailRow}>
                        <BodyText style={styles.label}>Experience:</BodyText>
                        <BodyText style={styles.value}>{job.experience}</BodyText>
                    </View>

                    <View style={styles.detailRow}>
                        <BodyText style={styles.label}>Job Type:</BodyText>
                        <BodyText style={styles.value}>{job.job_type}</BodyText>
                    </View>

                    <View style={styles.detailRow}>
                        <BodyText style={styles.label}>Role:</BodyText>
                        <BodyText style={styles.value}>{job.job_role}</BodyText>
                    </View>

                    <View style={styles.detailRow}>
                        <BodyText style={styles.label}>Qualification:</BodyText>
                        <BodyText style={styles.value}>{job.qualification}</BodyText>
                    </View>
                </View>

                <View style={styles.footer}>
                    <BodyText style={styles.jobId}>Job ID: {job.id}</BodyText>
                </View>
            </View>
        </TouchableOpacity>
    );
}

const styles = StyleSheet.create({
    container: {
        marginBottom: 16,
        borderRadius: 12,
        backgroundColor: '#fff',
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.1,
        shadowRadius: 4,
        elevation: 3,
    },
    content: {
        padding: 16,
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        marginBottom: 12,
    },
    titleContainer: {
        flex: 1,
        marginRight: 8,
    },
    title: {
        fontSize: 16,
        fontWeight: 'bold',
        marginBottom: 4,
    },
    companyName: {
        color: '#666',
        marginBottom: 8,
    },
    statsRow: {
        flexDirection: 'row',
        gap: 12,
    },
    statsText: {
        fontSize: 12,
        color: '#666',
    },
    details: {
        gap: 8,
        backgroundColor: '#f8f9fa',
        padding: 12,
        borderRadius: 8,
        marginTop: 8,
    },
    detailRow: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    label: {
        width: 100,
        color: '#666',
        fontSize: 13,
    },
    value: {
        flex: 1,
        color: '#333',
        fontSize: 13,
    },
    footer: {
        marginTop: 12,
        paddingTop: 12,
        borderTopWidth: 1,
        borderTopColor: '#eee',
    },
    jobId: {
        fontSize: 12,
        color: '#999',
    },
});
