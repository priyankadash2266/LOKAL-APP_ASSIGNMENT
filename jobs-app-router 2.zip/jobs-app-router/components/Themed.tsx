import { View as DefaultView, useColorScheme, ViewProps } from 'react-native';

export function useThemeColor(
  props: { light?: string; dark?: string },
  colorName: keyof typeof Colors.light & keyof typeof Colors.dark
) {
  const theme = useColorScheme() ?? 'light';
  const colorFromProps = props[theme];

  if (colorFromProps) {
    return colorFromProps;
  }
  return Colors[theme][colorName];
}

const Colors = {
  light: {
    background: '#fff',
    text: '#000',
  },
  dark: {
    background: '#000',
    text: '#fff',
  },
};

export type ThemeProps = {
  lightColor?: string;
  darkColor?: string;
};

export function View(props: ViewProps & ThemeProps) {
  const { style, lightColor, darkColor, ...otherProps } = props;
  const backgroundColor = useThemeColor(
    { light: lightColor, dark: darkColor },
    'background'
  );

  return <DefaultView style={[{ backgroundColor }, style]} {...otherProps} />;
}
