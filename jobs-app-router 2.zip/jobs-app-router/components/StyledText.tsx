import { Text, TextProps } from 'react-native';

export function HeadingText(props: TextProps) {
  return (
    <Text
      {...props}
      style={[
        {
          fontSize: 20,
          fontWeight: 'bold',
          color: '#000',
        },
        props.style,
      ]}
    />
  );
}

export function BodyText(props: TextProps) {
  return (
    <Text
      {...props}
      style={[
        {
          fontSize: 16,
          color: '#666',
        },
        props.style,
      ]}
    />
  );
}
