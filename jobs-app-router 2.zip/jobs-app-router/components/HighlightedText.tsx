import React from 'react';
import { StyleSheet, Text, TextStyle } from 'react-native';

type Props = {
    text: string;
    highlight: string;
    style?: TextStyle;
    highlightStyle?: TextStyle;
    numberOfLines?: number;
};

export default function HighlightedText({
    text,
    highlight,
    style,
    highlightStyle,
    numberOfLines
}: Props) {
    if (!highlight.trim()) {
        return <Text style={style} numberOfLines={numberOfLines}>{text}</Text>;
    }

    // Case insensitive search
    const regex = new RegExp(`(${highlight.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
    const parts = text.split(regex);

    return (
        <Text style={style} numberOfLines={numberOfLines}>
            {parts.map((part, i) => (
                regex.test(part) ? (
                    <Text key={i} style={[styles.highlight, highlightStyle]}>
                        {part}
                    </Text>
                ) : (
                    <Text key={i}>{part}</Text>
                )
            ))}
        </Text>
    );
}

const styles = StyleSheet.create({
    highlight: {
        backgroundColor: '#FFEB3B',
        fontWeight: 'bold',
    },
});
