import AsyncStorage from '@react-native-async-storage/async-storage';
import { useEffect, useState } from 'react';
import { StyleSheet, View } from 'react-native';
import { Divider, List, Menu, Searchbar } from 'react-native-paper';
import { useDebounce } from '../hooks/useDebounce';
import { setSearchQuery } from '../store/filterSlice';
import { useAppDispatch } from '../store/hooks';

const SEARCH_HISTORY_KEY = '@jobs_search_history';
const MAX_HISTORY_ITEMS = 5;

export default function SearchBar() {
    const dispatch = useAppDispatch();
    const [query, setQuery] = useState('');
    const [showHistory, setShowHistory] = useState(false);
    const [searchHistory, setSearchHistory] = useState<string[]>([]);

    // Load search history on mount
    useEffect(() => {
        loadSearchHistory();
    }, []);

    // Debounce search to prevent excessive updates
    useDebounce(() => {
        dispatch(setSearchQuery(query));
        if (query.trim()) {
            saveToSearchHistory(query);
        }
    }, 300, [query]);

    const loadSearchHistory = async () => {
        try {
            const history = await AsyncStorage.getItem(SEARCH_HISTORY_KEY);
            if (history) {
                setSearchHistory(JSON.parse(history));
            }
        } catch (error) {
            console.error('Failed to load search history', error);
        }
    };

    const saveToSearchHistory = async (term: string) => {
        try {
            const trimmedTerm = term.trim();
            if (!trimmedTerm) return;

            // Don't add duplicates
            const newHistory = [
                trimmedTerm,
                ...searchHistory.filter(item => item !== trimmedTerm)
            ].slice(0, MAX_HISTORY_ITEMS);

            setSearchHistory(newHistory);
            await AsyncStorage.setItem(SEARCH_HISTORY_KEY, JSON.stringify(newHistory));
        } catch (error) {
            console.error('Failed to save search history', error);
        }
    };

    const clearSearchHistory = async () => {
        try {
            setSearchHistory([]);
            await AsyncStorage.removeItem(SEARCH_HISTORY_KEY);
        } catch (error) {
            console.error('Failed to clear search history', error);
        }
    };

    const handleHistoryItemPress = (item: string) => {
        setQuery(item);
        dispatch(setSearchQuery(item));
        setShowHistory(false);
    };

    return (
        <View style={styles.container}>
            <Searchbar
                placeholder="Search jobs..."
                onChangeText={setQuery}
                value={query}
                style={styles.searchBar}
                onFocus={() => setShowHistory(true)}
                onBlur={() => setTimeout(() => setShowHistory(false), 200)}
            />

            {showHistory && searchHistory.length > 0 && (
                <Menu
                    visible={showHistory}
                    onDismiss={() => setShowHistory(false)}
                    anchor={{ x: 0, y: 0 }}
                    style={styles.historyMenu}
                >
                    {searchHistory.map((item, index) => (
                        <List.Item
                            key={index}
                            title={item}
                            left={props => <List.Icon {...props} icon="history" />}
                            onPress={() => handleHistoryItemPress(item)}
                        />
                    ))}
                    <Divider />
                    <List.Item
                        title="Clear Search History"
                        left={props => <List.Icon {...props} icon="delete" />}
                        onPress={clearSearchHistory}
                    />
                </Menu>
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        position: 'relative',
        zIndex: 1,
    },
    searchBar: {
        marginHorizontal: 16,
        marginVertical: 8,
        elevation: 2,
    },
    historyMenu: {
        marginTop: 60,
        marginHorizontal: 16,
        width: '90%',
    },
});
