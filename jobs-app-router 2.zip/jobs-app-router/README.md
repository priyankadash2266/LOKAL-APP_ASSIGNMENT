# Jobs App

A React Native mobile application built with Expo Router for browsing and managing job listings. The app features infinite scrolling, search functionality, and bookmark management.

## Features

### Core Features
- **Infinite Scroll Job Listings**
  - Smooth scrolling experience
  - Loads next page at 60% scroll threshold
  - Automatic duplicate prevention
  - Loading states and indicators

- **Search & Filter**
  - Real-time job search
  - Debounced input for performance
  - Highlighted search matches
  - Client-side filtering

- **Bookmark System**
  - Save jobs for later viewing
  - Persistent storage using AsyncStorage
  - Dedicated bookmarks tab
  - Optimistic UI updates

### Technical Features
- **Performance Optimized**
  - Efficient list rendering with FlatList
  - Scroll position optimization
  - Debounced search input
  - Memory efficient list management

- **Local Storage**
  - AsyncStorage for persistent data
  - Stores bookmarked jobs
  - Efficient data serialization
  - Optimistic updates for better UX

- **Developer Experience**
  - Feature flag system for development features
  - Comprehensive logging system
  - Debug panel (enabled via feature flag)
  - Type-safe codebase with TypeScript

## Project Structure

```
jobs-app-router/
├── app/                    # Main application screens
│   ├── (tabs)/            # Tab-based navigation
│   │   ├── index.tsx      # Jobs listing screen
│   │   └── bookmarks.tsx  # Bookmarks screen
│   └── job/
│       └── [id].tsx       # Job details screen
├── components/            # Reusable components
│   ├── JobCard.tsx       # Job listing card
│   ├── SearchBar.tsx     # Search input component
│   └── ErrorView.tsx     # Error state component
├── config/               # Configuration files
│   └── features.ts      # Feature flags
├── store/               # Redux store setup
│   ├── index.ts        # Store configuration
│   ├── jobsSlice.ts    # Jobs state management
│   └── filterSlice.ts  # Search/filter state
├── types/              # TypeScript definitions
└── constants/         # App constants
```

## Setup & Running

### Prerequisites
- Node.js (v14 or newer)
- npm or yarn
- Expo CLI
- Expo Go app installed on your mobile device
- iOS Simulator or Android Emulator (optional)

### Installation
1. Clone the repository
```bash
git clone [repository-url]
cd jobs-app-router
```

2. Install dependencies
```bash
npm install
# or
yarn install
```

3. Start the development server with a clean cache
```bash
npx expo start --clear
```

4. Run on your device:
   - Open Expo Go app on your mobile device
   - Scan the QR code shown in the terminal
   - The app will load on your device

   Alternatively, run on simulators:
   ```bash
   # For iOS
   npm run ios
   # For Android
   npm run android
   ```

### Development Features

To enable development features like the debug panel:

1. Open `config/features.ts`
2. Set `DEVELOPER_MODE` to `true`
3. Restart the app

## Testing

The app includes several test scenarios:

- Infinite scroll behavior
- Search functionality
- Bookmark persistence
- Error states
- Loading states

Run tests with:
```bash
npm test
# or
yarn test
```

## Future Improvements

1. **Performance**
   - Implement virtualized lists for large datasets
   - Add pagination metadata to API responses
   - Optimize image loading and caching

2. **Features**
   - Add advanced filtering options
   - Implement server-side search
   - Add job application tracking
   - Support offline mode
   - Add push notifications

3. **Technical**
   - Add comprehensive test coverage
   - Implement error boundary system
   - Add analytics tracking
   - Improve type safety

4. **UI/UX**
   - Add pull-to-refresh animation
   - Improve loading states
   - Add skeleton screens
   - Enhance accessibility

## Data Storage

The app uses React Native's AsyncStorage as its local database:
- Persistent storage for bookmarked jobs
- Key-value pair storage system
- Asynchronous operations
- Automatic data serialization/deserialization
- Storage key: '@jobs_bookmarks'

## API Integration

The app integrates with a remote jobs API:
- Base URL: https://testapi.getlokalapp.com
- Endpoints:
  - `/common/jobs` - Get job listings
  - Parameters:
    - `page`: Page number (starts at 1)
    - Returns 11 jobs per page

## Contributing

1. Fork the repository
2. Create your feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request
