export interface Job {
    id: number;
    title: string;
    company_name: string;
    job_category: string;
    job_role: string;
    job_location_slug: string;
    primary_details: {
        Place: string;
        Salary: string;
        Job_Type: string;
        Experience: string;
        Qualification: string;
    };
    salary_min: number;
    salary_max: number;
    whatsapp_no: string;
    contact_preference: any;
    button_text: string;
    custom_link: string;
    other_details: string;
    job_hours: string;
    openings_count: number;
    experience: string;
    qualification: string;
    shift_timing: string;
    job_type: string;
    is_premium: boolean;
    is_bookmarked: boolean;
    created_on: string;
    updated_on: string;
    expire_on: string;
    num_applications?: number;
}

export interface JobsState {
    jobs: Job[];
    bookmarkedJobs: number[];
    currentPage: number;
    hasMore: boolean;
    loading: boolean;
    error: string | null;
    total: number;
}

export interface ApiResponse {
    results: Job[];
    message: string;
    status: number;
    total: number;
}
